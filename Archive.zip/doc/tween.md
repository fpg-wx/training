# Tween(GreenSock)

1. 设置参数（set）
2. 动画执行（from、to、fromTo）
3. 运动参数（css属性、autoAlpha、x、y、scale、scaleX、scaleY、rotation、rotationX、rotationY、rotationZ、skewX、skewY、className）
4. 缓动函数（多个分类、easeIn、easeOut、easeInOut）
5. 延迟（delay）
6. 重复（repeat、repeatDelay）
7. 往返（yoyo）
8. 回调函数及传参（onStart、onUpdate、onComplete、onRepeat）
9. 刷帧（useFrames）
10. 延迟调用（delayedCall）
11. 强制结束（killTweensOf、killDelayedCallsTo、killChildTweensOf、killAll、kill）