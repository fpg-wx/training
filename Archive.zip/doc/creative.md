# Quiz Whiz

Using HTML5 and a backend language of choice, create a three question quiz that tallies responses on the server and upon completion, presents results in an interesting way. Any out-of-the-box interface components should be custom styled.