# Vue

> 看2.0版本！！！看2.0版本！！！看2.0版本！！！

## 基础

- 实例创建
- 实例生命周期
- 数据绑定
- 计算属性
- 观察者
- class绑定
- 条件渲染
- 列表渲染
- 事件注册
- vue单文件（结合webpack）




## 深入

- ref
- 过渡效果
- slot
- 自定义命令
- mixin




## 工程化

- vue-router（2.0）
- vue-resource
- vuex（2.0）