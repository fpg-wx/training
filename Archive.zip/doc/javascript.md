# Javascript

1. 引用（文档加载完成后）
2. 在浏览器控制台查看变量值
3. 基础（顺序、条件判断、循环、数组、对象）
4. setInterval、setTimeout、clearInterval、clearTimeout
5. 数组常用方法
6. 字符串常用方法
7. 常用数学函数
8. requestAnimationFrame
9. canvas
10. video、audio


