# React

> 强烈建议看官方原版教程，[中文教程](https://hulufei.gitbooks.io/react-tutorial/content/index.html)只做参考用（版本滞后，慎看）

## 基础

- 数据驱动的概念
- 环境配置
- 熟悉jsx语法
- 渲染固定内容到页面
- props和state的区别与应用场景
- 事件注册
- 条件渲染
- 列表渲染
- 生命周期函数
- 父子组件之间数据传递
- 获取组件中的dom元素



## 最佳实践

看文档🙄



## 考核

### 跟着官方教程demo做一个xo棋（0.5d）

- [点击访问](https://facebook.github.io/react/tutorial/tutorial.html)