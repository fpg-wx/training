# jQuery

1. 选择器
2. 元素选择（eq、find、parents、next、prev、index）
3. dom操作（新建、remove、prepend、append、before、after）
4. dom元素和jquery元素区别与转换（eq、get、[]）
5. 属性样式操作（attr、data、css）
6. 类操作（addClass、removeClass、toggleClass、hasClass）
7. 获取宽高（width、height）
8. 获取内容（html、text）
9. 定位（offset、position）
10. 表单（val）
11. 事件（on、off、trigger）
12. 事件参数（e）
13. 阻止事件触发、冒泡
14. 工具函数（trim、each、inArray、extend）
15. ajax